# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['rrquant',
 'rrquant.index',
 'rrquant.rqData_es',
 'rrquant.rqData_es.api',
 'rrquant.rqData_es.bond',
 'rrquant.rqData_es.common',
 'rrquant.rqData_es.config',
 'rrquant.rqData_es.fund',
 'rrquant.rqData_es.futures',
 'rrquant.rqData_es.shared',
 'rrquant.rqData_es.stock',
 'rrquant.rqData_es.utils',
 'rrquant.rqData_pytdx',
 'rrquant.rqUtil',
 'rrquant.stock',
 'rrquant.stock_feature',
 'rrquant.utils']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'rrquant',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'romepeng',
    'author_email': 'romepeng@outlook.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
